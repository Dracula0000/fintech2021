export interface CardForm {
  type : string;
  name : string;
  surname :  string;
  cardNumber :  string; //min e max 16 caratteri
  secureCode  :  string; //min e max 3 caratteri
}



//export const cardTypes = ['mastercard','visa'];


